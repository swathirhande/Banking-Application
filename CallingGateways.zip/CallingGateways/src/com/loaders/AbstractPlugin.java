package com.loaders;

public abstract class AbstractPlugin {
	public abstract void start(String n);
}
